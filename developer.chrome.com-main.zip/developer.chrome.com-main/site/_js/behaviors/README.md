Because web components can't extend native elements we use behaviors to imbue
native elements with additional powers. This is particularly useful for
toggleable ARIA behaviors (aria-expanded, aria-selected).