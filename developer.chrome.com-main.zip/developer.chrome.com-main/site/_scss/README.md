---
permalink: false
---

This CSS is organized aroud the <http://cube.fyi/> structure.

A few rules:

- When using a color, always use one of the color variables from _theme.scss.
This will ensure that the color changes when the user switches to dark mode.
