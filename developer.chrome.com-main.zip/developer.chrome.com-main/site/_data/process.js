/**
 * @fileoverview Expose Node's process to eleventy's nunjucks templates.
 */

module.exports = {
  env: process.env,
};
