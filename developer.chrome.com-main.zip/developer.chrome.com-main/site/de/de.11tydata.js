module.exports = {
  locale: 'de',
};
