module.exports = {
  type: 'doc',
};
