---
layout: layouts/project-landing.njk
title: Die Privacy Sandbox
description: Die Privacy-Sandbox-Initiative bezeichnet eine Reihe von Vorschlägen zum Umsetzen von Cross-Site-Anwendungsfällen unter Ausschluss der Nutzung von Drittanbieter-Cookies oder anderen Tracking-Mechanismen.
---
