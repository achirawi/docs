---
title: '#100CoolWebMoments'
description: 'Take a stroll down memory lane and celebrate #100CoolWebMoments since Chrome’s first release.'
thumbnail: image/x1Los57vDga6OEMNi1dIJwZ0qvp2/1gyOFYMC1sFOBkC5csD3.png
alt: 'Chrome 100'
layout: 'layouts/chrome-100.njk'
type: landing
---
