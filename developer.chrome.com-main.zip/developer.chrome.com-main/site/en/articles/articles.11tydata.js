module.exports = {
  type: 'article',
};
