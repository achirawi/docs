{% Aside %}
Manifest V3 is supported generally in Chrome 88 or later. For extension features added in later Chrome versions, see the [API reference documentation](/docs/extensions/reference/) for support information. If your extension requires a specific API, you can specify [a minimum chrome version](/docs/extensions/mv3/manifest/minimum_chrome_version/) in the manifest file.
{% endAside %}
