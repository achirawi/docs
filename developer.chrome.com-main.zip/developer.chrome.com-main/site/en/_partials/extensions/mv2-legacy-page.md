{% Aside 'warning' %}
The Chrome Web Store no longer accepts Manifest V2 extensions. Please use [Manifest
V3](/docs/extensions/mv3/intro) when building new extensions. You will find a section on upgrading in the navigation tree at the left, including the [Manifest V2 support timeline](/docs/extensions/mv3/mv2-sunset/).
{% endAside %}
