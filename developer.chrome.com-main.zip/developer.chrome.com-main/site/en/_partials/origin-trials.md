Origin trials allow you to try new features and give feedback on their
usability, practicality, and effectiveness to the web standards community. For
more information, see the [Origin Trials Guide for Web Developers](https://github.com/GoogleChrome/OriginTrials/blob/gh-pages/developer-guide.md).
To sign up for this or another origin trial, visit the [registration page](https://developers.chrome.com/origintrials/#/trials/active).
