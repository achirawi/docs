{% Aside %}
This API is a work in progress and will evolve over time, dependent on
ecosystem feedback and input. Your input helps ensure that solutions to various
use cases are discussed.

This API is being incubated and developed in the open. [Consider participating](/docs/privacy-sandbox/attribution-reporting-introduction/#participate)
in the discussion.
{% endAside %}
