## Get updates

*  To be notified of status changes in the API, join the [mailing list for developers](https://groups.google.com/u/1/a/chromium.org/g/attribution-reporting-api-dev).
*  To closely follow all ongoing discussions on the API, click the **Watch**
   button on the [GitHub proposal](https://github.com/WICG/conversion-measurement-api).
   This requires you to have or [create a GitHub account](https://docs.github.com/en/get-started/signing-up-for-github/signing-up-for-a-new-github-account).
*  To get overall updates on the Privacy Sandbox, subscribe to the RSS feed
   [Progress in the Privacy Sandbox](/tags/progress-in-the-privacy-sandbox/).
