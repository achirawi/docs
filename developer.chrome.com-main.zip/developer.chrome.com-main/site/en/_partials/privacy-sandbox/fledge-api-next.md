## What's next?

We want to engage in conversations with you to ensure we build an API that
works for everyone.

### Discuss the API

Like other Privacy Sandbox proposals, this API is documented and
[discussed publicly](/docs/privacy-sandbox/fledge/#engage).

### Experiment with the API

You can [experiment and participate](/docs/privacy-sandbox/fledge-experiment/)
in conversation about the FLEDGE API.
