## Engage and share feedback

You can [participate and experiment with this API](/docs/privacy-sandbox/attribution-reporting-experiment/).

*  Read the [client-side proposal](https://github.com/WICG/conversion-measurement-api/blob/main/AGGREGATE.md) and [aggregation service proposal](https://github.com/WICG/conversion-measurement-api/blob/main/AGGREGATION_SERVICE_TEE.md), ask questions, and suggest feedback.
*  Read the [Strategy and tips for summary reports](https://docs.google.com/document/d/1bU0a_njpDcRd9vDR0AJjwJjrf3Or8vAzyfuK8JZDEfo/edit?usp=sharing).
* Ask questions and join discussions on the [Privacy
   Sandbox Developer Support repo](https://github.com/GoogleChromeLabs/privacy-sandbox-dev-support).