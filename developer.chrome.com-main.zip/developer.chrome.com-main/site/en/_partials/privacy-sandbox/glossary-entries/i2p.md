Intent to Prototype (I2P) is the first stage in
[developing a new feature](/blog/progress-in-the-privacy-sandbox-2021-12/#chromium-development-process)
in [Blink](#blink). The announcement is posted to the [blink-dev mailing
list](https://groups.google.com/a/chromium.org/g/blink-dev) with a link to the
proposal for discussion.
