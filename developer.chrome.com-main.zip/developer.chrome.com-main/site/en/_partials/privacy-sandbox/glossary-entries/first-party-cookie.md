A first-party [cookie](#cookie) is a cookie stored by a website while a user is on the site itself.

For example, an online store might ask a browser to store a cookie in order to
retain shopping cart details for a user who is not logged in. See also
[Third-party cookies](#third-party-cookie).
