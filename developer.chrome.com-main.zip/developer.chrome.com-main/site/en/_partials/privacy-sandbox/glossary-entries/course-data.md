Course data refers to limited information provided by Attribution Reporting API event-level reports.
This is limited to 3 pieces of conversion data for clicks and 1 piece for
views. Specific, granular conversion data (such as specific prices of items
and timestamps)  are not included.