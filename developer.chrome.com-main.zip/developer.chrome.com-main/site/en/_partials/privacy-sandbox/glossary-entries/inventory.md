Inventory is the ad slots available on a site. Ad slots are the HTML markup (usually `<div>`
tags) where ads can be displayed.