Blink is the [rendering engine](https://en.wikipedia.org/wiki/Browser_engine) used by
Chrome, developed as part of the [Chromium](#chromium) project.