An ad platform is a company that provides services to deliver ads.
