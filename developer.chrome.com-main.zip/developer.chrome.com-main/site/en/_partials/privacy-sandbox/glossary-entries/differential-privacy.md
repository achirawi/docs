Differential privacy refers to techniques to allow sharing of information about a dataset to reveal patterns
of behaviour without revealing private information about individuals or whether
they belong to the dataset.
