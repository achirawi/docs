A data management platform is software used to collect and manage data relevant for advertisers. These
platforms help advertisers and publishers identify audience segments, which can
then be used for campaign targeting.

Learn more about [DMPs](https://en.wikipedia.org/wiki/Data_management_platform).
