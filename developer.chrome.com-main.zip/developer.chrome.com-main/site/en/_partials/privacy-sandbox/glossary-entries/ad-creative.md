Ad creative refers to the contents of the ad served to users. Creatives can be images, videos, audio,
and other formats. Creatives live within an ad space, and are served by ad tech
within line items.
