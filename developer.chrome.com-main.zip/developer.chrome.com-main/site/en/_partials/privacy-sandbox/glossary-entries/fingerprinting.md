Fingerprinting encompasses techniques to identify and track the behaviour of individual users.

Fingerprinting uses mechanisms that users aren't aware of and can't control. 
Sites such as [Panopticlick](https://panopticlick.eff.org) and
[amiunique.org](https://amiunique.org/) show how fingerprint data can be
combined to identify you as an individual.
