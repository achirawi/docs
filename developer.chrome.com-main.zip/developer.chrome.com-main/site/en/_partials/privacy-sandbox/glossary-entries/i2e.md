Intent to Experiment (I2E) is the announcement of a plan to make a new [Blink](#blink)
feature available to users for testing, typically through an [origin
trial](#origin-trial).