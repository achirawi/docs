A seller is the party running an ad auction, likely to be an [SSP](#ssp) or maybe the
publisher itself.