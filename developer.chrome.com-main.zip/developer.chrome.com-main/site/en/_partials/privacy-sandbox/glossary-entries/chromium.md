Chromium is an open-source web browser project. Chrome, Microsoft Edge, Opera and other
browsers are based on Chromium.