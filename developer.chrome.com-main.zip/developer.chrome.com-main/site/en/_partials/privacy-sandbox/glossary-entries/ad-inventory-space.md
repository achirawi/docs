Ad inventory space is the space or spaces for ads that are available from a site that sells ad space.
