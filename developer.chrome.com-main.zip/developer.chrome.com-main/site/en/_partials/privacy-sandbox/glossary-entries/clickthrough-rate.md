The click-through rate is the ratio of users who click on an ad, having seen it.

See also [impression](#impression).