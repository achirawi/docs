Fderated identity is a third-party platform to allow a user to sign in to a website, without
requiring the site to implement their own identity service.
