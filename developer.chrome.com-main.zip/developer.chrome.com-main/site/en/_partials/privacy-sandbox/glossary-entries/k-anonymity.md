K-anonymity is the measure of anonymity within a data set. If you have _k_ anonymity, you can't
be distinguished from _k-1_ other individuals in the data set. In other words,
_k_ individuals have the same information (including you).