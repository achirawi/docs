Impression could refer to either:

*  View of an ad. See also [click-through rate](#ctr).
*  An ad slot: the HTML markup (usually `<div>` tags) on a web page where an ad
   can be displayed. Ad slots constitute [inventory](#inventory).