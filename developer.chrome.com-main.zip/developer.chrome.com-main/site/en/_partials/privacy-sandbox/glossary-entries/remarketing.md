Remarketing is the practice of advertising to people who've already visited your site on other sites.

For example, an online store could show ads for a toy sale to people who
previously viewed toys on their site.