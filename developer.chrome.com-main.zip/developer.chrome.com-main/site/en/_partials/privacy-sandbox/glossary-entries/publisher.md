In the Privacy Sandbox context, a publisher is a site with ad space that is paid to display
ads.