A summary report is an Attribution Reporting API and Private Aggregation API report type. A [summary
report](/docs/privacy-sandbox/attribution-reporting/summary-reports/) includes
aggregated user data and detailed conversion data, resulting from noisy
aggregation applied to aggregatable reports. The summary
includes aggregated user data and detailed conversion data.

Summary reports were formerly known as aggregate reports.