Real-time bidding refers to an automated auction for buying and selling ad impressions on websites,
completed during page load.