A [worklet](https://developer.mozilla.org/docs/Web/API/Worklet) allows you to run specific JavaScript functions and return information back to the requester. Within a worklet, you can execute JavaScript but you cannot interact or communicate with the outside page.

Worklets are used to store and extract data with the [Shared Storage API](/docs/privacy-sandbox/shared-storage/).