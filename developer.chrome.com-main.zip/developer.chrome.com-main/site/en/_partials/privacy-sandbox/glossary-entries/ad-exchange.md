An ad exchange is a platform to automate buying and selling of ad inventory from multiple ad
networks.

{: #ad-space }
