In FLEDGE, an ad auction is run by a seller (likely to be an [SSP](#ssp) or maybe the publisher itself), in JavaScript code in the browser on the
user's device, to sell ad space on a site that displays ads.

{: #creative}