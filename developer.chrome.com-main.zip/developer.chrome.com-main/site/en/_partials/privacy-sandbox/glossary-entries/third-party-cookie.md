A third-party [cookie](#cookie) is a cookie stored by a third-party service.

For example, a video website might include a **Watch Later** button in their
embedded player to allow a user to add a video to their wishlist without
forcing them to navigate to the video site.

See also [First-party cookie](#first-party-cookie).