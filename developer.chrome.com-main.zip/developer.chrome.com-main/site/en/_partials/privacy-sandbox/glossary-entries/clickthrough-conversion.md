A click-through conversion is a conversion attributed to an ad that was clicked.
