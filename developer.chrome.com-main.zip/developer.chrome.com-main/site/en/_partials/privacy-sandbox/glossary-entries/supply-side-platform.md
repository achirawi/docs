A supply-side platform is an ad tech service used to automate selling ad inventory. SSPs allow publishers
to offer their inventory (empty rectangles where ads will go) to multiple ad
exchanges, [DSPs](#DSP), and networks. This enables a wide range of potential
buyers to bid for ad space.