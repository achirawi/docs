Federated Credential Management API is a proposal for a privacy-preserving
approach to federated identity services. This will allow users to log into
sites without sharing their personal information with the identity service or
the site.

FedCM was previously known as WebID, and is still
[in development in the W3C](https://github.com/wicg/fedcm).
