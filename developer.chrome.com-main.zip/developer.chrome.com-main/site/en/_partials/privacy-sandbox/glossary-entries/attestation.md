Attestation is a mechanism to authenticate software identity, usually with [cryptographic
hashes](https://en.wikipedia.org/wiki/Cryptographic_hash_function) or
signatures. For the aggregation service proposal, attestation matches the
code running in the ad tech-operated aggregation service with the open
source code.