An origin is defined by the scheme (protocol), hostname (domain), and port of the URL used to access it.

For example: `https://developer.chrome.com`