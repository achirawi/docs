The reporting origin is the entity that receives aggregatable reports&mdash;in other words, the ad tech
that called the Attribution Reporting API. Aggregatable reports are sent from
user devices to a [well-known](#well-known) URL associated with the reporting
origin.