Intent to Extend Experiment (I2EE) is an announcement of a plan to extend the duration of an
[origin trial](#origin-trial).