Surface. See [Fingerprinting surface](#fingerprinting-surface) and
[Passive surface](#passive-surface).