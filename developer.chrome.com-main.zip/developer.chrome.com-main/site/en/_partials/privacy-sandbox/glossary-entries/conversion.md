A conversion is the completion of some desired goal following action by a user.

For example, a conversion may occur with the purchase of a product or sign-up
for a newsletter after clicking an ad that links to the advertiser's site.