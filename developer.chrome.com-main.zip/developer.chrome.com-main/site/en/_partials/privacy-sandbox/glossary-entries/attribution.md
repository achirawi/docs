Attribution refers to the identification of user actions that contribute to an outcome.

For example, a correlation of ad clicks or views with [conversions](#conversion).