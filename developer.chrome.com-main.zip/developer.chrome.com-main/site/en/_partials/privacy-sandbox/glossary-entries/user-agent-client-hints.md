User-agent client hints provide specific pieces of the User-Agent string on explicit request. This
helps reduce [passive surfaces](#passive-surface) in the User-Agent string
which may lead to user identification or covert tracking.

UA-CH is sometimes referred to as "Client Hints."