Intent to Ship (I2S) is an announcement of a plan to make a new feature of [Blink](#blink)
available to users in stable versions of Chrome.