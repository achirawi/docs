Aggregatable reports are encrypted reports sent from individual user devices. These reports contain
data about cross-site user behavior and conversions. Conversions (sometimes
called attribution trigger events) and associated metrics are defined by the
advertiser or ad tech. Each report is encrypted to prevent various parties
from accessing the underlying data.