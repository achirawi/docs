A buyer  is a party bidding for ad space in an [ad auction](#ad-auction), likely to be a
[DSP](#DSP), or maybe the advertiser itself. Ad space buyers own and manage
interest groups. 

Learn about [ad space buyers in FLEDGE](/docs/privacy-sandbox/fledge/#buyer-detail).