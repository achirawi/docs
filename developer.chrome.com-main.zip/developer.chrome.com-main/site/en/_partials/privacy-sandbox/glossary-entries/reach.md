Reach represents the total number of people who see an ad or who visit a web page that displays
the ad.