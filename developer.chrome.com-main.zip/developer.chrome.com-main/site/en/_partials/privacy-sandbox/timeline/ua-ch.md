*  [Overview of User-Agent reduction](/docs/privacy-sandbox/user-agent/)
*  [Origin trial](/blog/user-agent-reduction-origin-trial/) Chrome 95 to 103
*  [Deprecation trial](/blog/user-agent-reduction-deprecation-trial/) Chrome 103 to Chrome 112
*  [Chrome DevTools integration](/blog/new-in-devtools-89/#ua-ch)
*  Review the [UA-CH Chrome platform status](https://chromestatus.com/feature/5995832180473856)

User-Agent Client Hints API documentation is available on [MDN](https://developer.mozilla.org/docs/Web/API/User-Agent_Client_Hints_API).
