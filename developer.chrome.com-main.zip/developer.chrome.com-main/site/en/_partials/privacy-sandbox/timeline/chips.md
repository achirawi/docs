* [Chrome platform status](https://chromestatus.com/feature/5179189105786880)
* An [origin trial](/origintrials/#/view_trial/1239615797433729025) was available from Chrome 100 to 106.
* Read the [Intent to Experiment](https://groups.google.com/a/chromium.org/g/blink-dev/c/_dJFNJpf91U) and [Intent to Ship](https://groups.google.com/a/chromium.org/g/blink-dev/c/JNOQvsTxecI/m/V-OewM3lAwAJ).
