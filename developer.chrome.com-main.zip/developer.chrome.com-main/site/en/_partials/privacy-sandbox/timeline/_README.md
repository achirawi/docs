## Using timeline tables and statuses

These partials contain implementation status links and some tables for feature release timelines. If you use these partials, headings are not automatically included.

```txt
## Implementation status

{% Partial 'privacy-sandbox/timeline/attribution-reporting.njk' %}
```

These partials don't have line spacing before the content, thus the line space between the header and the partial reference is necessary, as above.


