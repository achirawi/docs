*  The [FLEDGE proposal](https://github.com/WICG/turtledove/blob/master/FLEDGE.md) is now approaching launch for scaled adoption.
   [Raise questions and follow discussion](https://github.com/WICG/turtledove/issues).
*  [FLEDGE status of pending capabilities](/docs/privacy-sandbox/fledge-api/feature-status/) details changes and enhancements to the FLEDGE API and features.
*  [Blink status](https://groups.google.com/a/chromium.org/g/blink-dev/search?q=fledge)
*  [FLEDGE Chrome platform status](https://chromestatus.com/feature/5733583115255808): Specific to the FLEDGE API on Chrome.
*  [Ads API Chrome platform status](https://chromestatus.com/feature/5100526168440832): A collection of APIs to facilitate advertising: FLEDGE, Topics, Fenced Frames and Attribution Reporting.

To be notified of status changes in the API, join the [mailing list for
developers](https://groups.google.com/u/3/a/chromium.org/g/fledge-api-announce).
