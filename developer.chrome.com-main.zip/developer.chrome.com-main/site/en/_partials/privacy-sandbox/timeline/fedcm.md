*  [Chrome Platform Status](https://chromestatus.com/feature/6438627087220736)
*  FedCM shipped in Chrome 108.
*  The [FedCM proposal](https://github.com/fedidcg/FedCM) is open for [public
   discussion](https://github.com/fedidcg/FedCM/issues).
*  FedCM isn't supported in other browsers yet.
   * Mozilla is [implementing a prototype](https://bugzilla.mozilla.org/show_bug.cgi?id=1782066)
     for Firefox and
     [Apple has expressed general support](https://lists.webkit.org/pipermail/webkit-dev/2022-March/032162.html)
     and interest in working together on the FedCM proposal.
