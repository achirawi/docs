*  First-Party Sets is in incubation in [WICG](https://github.com/WICG/first-party-sets/issues)
*  The first [origin trial](https://web.dev/origin-trials/) ran from Chrome 89 to 93.
*  [Chrome Platform Status](https://chromestatus.com/feature/5640066519007232).
*  [Blink status](https://groups.google.com/a/chromium.org/g/blink-dev/search?q=first-party%20sets).
*  [Chromium Projects](https://www.chromium.org/updates/first-party-sets)
*  [First-Party Sets submission guidelines](https://github.com/GoogleChrome/first-party-sets/blob/main/FPS-Submission_Guidelines.md)
