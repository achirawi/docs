*   The [Shared Storage proposal](https://github.com/WICG/shared-storage) has entered [public discussion](https://github.com/WICG/shared-storage/issues).
*   A [live demo is available](#try-the-shared-storage-api), as is testing:
    *   URL selection output gate is available for local testing from Chrome M105+. 
    *   Private Aggregation output gate is available for local testing from Chrome M107+.
    *  Measurement with the Private Aggregation API is available in the [Privacy Sandbox Unified Origin Trial](/docs/privacy-sandbox/unified-origin-trial/) from Chrome M107+ Beta.
*  [Chrome platform status](https://chromestatus.com/feature/6256348582903808)
