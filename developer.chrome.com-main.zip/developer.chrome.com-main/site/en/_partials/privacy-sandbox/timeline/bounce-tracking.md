* The [Bounce tracking mitigations proposal](https://github.com/wanderview/bounce-tracking-mitigations/blob/main/explainer.md)
  has entered [public discussion](https://github.com/wanderview/bounce-tracking-mitigations/issues).
* [Chrome platform status](https://chromestatus.com/feature/5705149616488448?context=myfeatures).
* This proposal has not been implemented in any browser.