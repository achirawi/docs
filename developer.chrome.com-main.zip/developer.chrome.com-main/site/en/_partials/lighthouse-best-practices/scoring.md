{% Aside 'note' %}
  Each Best Practices audit is weighted equally in the Lighthouse Best Practices
  Score. Learn more in [The Best Practices
  score](/docs/lighthouse/performance/performance-scoring/#best-practices).
{% endAside %}
