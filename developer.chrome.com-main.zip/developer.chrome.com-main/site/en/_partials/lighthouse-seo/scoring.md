{% Aside 'note' %}
  Each SEO audit is weighted equally
  in the Lighthouse SEO Score,
  except for the manual **[Structured data is valid](/docs/lighthouse/seo/structured-data/)** audit.
  Learn more in the [Lighthouse Scoring Guide](/docs/lighthouse/performance/performance-scoring/).
{% endAside %}
