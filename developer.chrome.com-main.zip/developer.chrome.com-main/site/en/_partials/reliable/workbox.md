{% Aside 'success' %}
  [Workbox](/docs/workbox/) is the recommended approach for adding
  service workers to websites because it automates a lot of
  boilerplate, makes it easier to follow best practices, and
  prevents subtle bugs that are common when using the low-level
  `ServiceWorker` API directly.
{% endAside %}
