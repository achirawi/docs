{% Aside 'note' %}
  In the Lighthouse report UI the full PWA badge is given when you pass all of the
  audits in all of the PWA subcategories (**Fast and reliable**, **Installable**, and **PWA optimized**).
{% endAside %}
