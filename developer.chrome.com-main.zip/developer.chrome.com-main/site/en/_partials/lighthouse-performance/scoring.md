{% Aside 'note' %}
  See the
  [Lighthouse performance scoring](/docs/lighthouse/performance/performance-scoring/) post to learn
  how your page's overall performance score is calculated.
{% endAside %}
