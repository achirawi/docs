1. [Request a token]({{origin_trial.url}}) for your origin.
2. Add the token to your pages. There are two ways to do that:
     * Add an `origin-trial` `<meta>` tag to the head of each page. For example,
       this may look something like: <br>
       `<meta http-equiv="origin-trial" content="TOKEN_GOES_HERE">`
     * If you can configure your server, you can also add the token
       using an `Origin-Trial` HTTP header. The resulting response header should
       look something like:<br>
       `Origin-Trial: TOKEN_GOES_HERE`
