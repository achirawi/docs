{% Aside 'warning' %}
Deprecation of the technologies described here has been announced
for platforms other than ChromeOS.

Please visit our [migration guide](/docs/native-client/migration) for details.
{% endAside %}