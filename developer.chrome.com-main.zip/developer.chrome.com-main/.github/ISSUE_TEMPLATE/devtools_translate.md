---
name: DevTools translate
about: Translate a DevTools blog post
title: '[devtools-translate] Language - What's new in DevTools (Chrome XX)'
labels:
- 'devtools-translate'
assignees: 'chybie'

---

⚠️ This is for feature requests with the https://developer.chrome.com site, not Chromium itself.
If you want to file a bug with Chromium (the open-source project behind Google Chrome and other browsers), please use https://crbug.com.

Post: https://developer.chrome.com/blog/new-in-devtools-xx/
Hero image:
Banner image:

Translated by: 
Reviewed by: 
